from django.contrib import admin
from .models import Bus, Booking

admin.site.register(Bus)
admin.site.register(Booking)
